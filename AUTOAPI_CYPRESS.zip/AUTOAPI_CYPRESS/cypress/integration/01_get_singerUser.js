import DATA from '../fixtures/data';

describe('Get Single User', () => {
    it('Status code is 200', () => {
        cy.request(DATA.list).then((resp) => {
            //se valida el status code para la peticion
            expect(resp.status).to.eq(200)
        });
    });
    
});