module.exports = {
    "list":{
        "method":"GET",
        "url":"https://reqres.in/api/users/2"
    },
    


}