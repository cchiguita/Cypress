import { pages } from "./pages";

module.exports = { ...pages };
