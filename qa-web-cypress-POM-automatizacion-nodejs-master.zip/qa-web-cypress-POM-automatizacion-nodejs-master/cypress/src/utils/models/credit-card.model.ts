export interface CreditCardData {
  cardNumber: string;
  cvc: string;
  expirationMonth: string;
  expirationYear: string;
}
